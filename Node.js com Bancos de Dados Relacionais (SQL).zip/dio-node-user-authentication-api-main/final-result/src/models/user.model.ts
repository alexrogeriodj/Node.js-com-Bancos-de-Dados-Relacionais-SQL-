
export type User = {
    uuid: string;
    username: string;
    password?: string;
}
