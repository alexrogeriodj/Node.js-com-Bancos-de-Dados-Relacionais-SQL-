import { ApplicationError } from './application.error';

export class DatabaseError extends ApplicationError<any> {}
